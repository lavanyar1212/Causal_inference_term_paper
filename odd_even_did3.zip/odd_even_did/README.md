# Delhi Odd–Even and air pollution: DiD analysis

Code, output and logs for the term paper *Did Delhi's Odd–Even Rule Clean the Air?*

## Run it in Google Colab
1. In Google Drive, create a folder `odd_even_data` in "My Drive".
2. Put `stations.csv` and `station_hour.csv` from the Kaggle dataset
   *Air Quality Data in India (2015–2020)* (https://www.kaggle.com/datasets/rohanrao/air-quality-data-in-india) in it.
3. Open `odd_even_did_analysis.ipynb` in Colab (File → Upload notebook), then Runtime → Run all.
   Allow Drive access when asked. A full run takes about 15 minutes.
4. Results are written to `odd_even_data/outputs/` in your Drive.

## Files
| File | What it is |
|---|---|
| `odd_even_did_analysis.ipynb` / `.html` | The full analysis, already run |
| `outputs/table1_summary_stats.csv`, `outputs/station_coverage.csv` | Table 1 and station coverage |
| `outputs/table2_main_results.csv` | Table 2: DiD, triple difference, within-Delhi, placebo p-values and placebo ranges, all 3 rounds |
| `outputs/table3_robustness.csv` | Table 3 (Nov 2019): pre-trends, anticipation, placebos, alternative controls, sample choices, after-rule |
| `outputs/table3_robustness_apr2016.csv` | Same checks for April 2016 (appendix) |
| `outputs/ri_sensitivity.csv` | Placebo p-values under different fake-date rules |
| `outputs/figure1_event_study.png` (+ CSVs) | Figure 1 and its data |
| `outputs/appendix_ri_distribution.png` | Where the real estimate falls among placebo estimates |
| `outputs/run_log.txt` | Full log of every number |

## Design choices
- Treated: 10 Delhi monitors running since 2015; city value = equal-weight mean of reporting stations. Control: Gurugram (HR014, HR011).
- Outcome: log of the 08:00–19:59 mean; a day needs at least 6 of 12 hours.
- Before window: 14 days before each round. Sundays and Diwali ±1 day dropped from every window; before-days reweighted to the rule days' weekday mix (in every estimate and placebo).
- Inference: placebo-date test. Fake start dates within ±75 days of the real date, in other years, on the same weekday (so each fake window has the same number and mix of rule days); windows touching Diwali, any real/announced round, the Nov 2019 announcement period (13 Sep–3 Nov 2019), or the 2020 COVID lockdown are skipped. A sensitivity table also uses Oct–Dec-only fake dates. p-value = share of placebo estimates whose absolute size is at least as large as the real estimate's. Not turned into confidence intervals.
- Jan 2016 has no between-city checks (Gurugram has no PM2.5 and almost no NO2).
